@extends('admin_layout')
@section('admin_content')
    <h1>Chào mừng bạn.Đây là trang Admin</h1>
@endsection