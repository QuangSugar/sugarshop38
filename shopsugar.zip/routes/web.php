<?php
Route::get('/clear-cache',function()
{
    $exitcode = Artisan::call('cache:clear');
});

use Illuminate\Support\Facades\Route;
// frontend
Route::get('/', 'HomeController@index');
Route::get('/trang-chu', 'HomeController@index');

//backend
Route::get('/admin', 'AdminController@index');
Route::get('/dashboard', 'AdminController@show_dashboard');
Route::post('/admin-dashboard', 'AdminController@dashboard');
Route::get('/logout', 'AdminController@logout');

// Category product
Route::get('/add-category', 'CategoryProduct@add_category');
Route::get('/all-category', 'CategoryProduct@all_category');
Route::post('/save-category', 'CategoryProduct@save_category');

Route::get('/unactive-category/{category_id}', 'CategoryProduct@unactive_category');
Route::get('/active-category/{category_id}', 'CategoryProduct@active_category');